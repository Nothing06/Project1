

#include <stdio.h>
#include <string.h>
#include <malloc.h>

#define LONGNUMBER_LENGTH 201

void print_longnumber( char *n );

int main( void )
{
	char number1[LONGNUMBER_LENGTH] = { '1', '1', '1', '1', '1' };
	char number2[LONGNUMBER_LENGTH] = { '8', '8', '8', '8', '8' };
	char number_result[LONGNUMBER_LENGTH] = { '0', };
	int i;

	printf("ù��° ����: ");
	print_longnumber( number1 );
	printf("\n");

	printf("�ι�° ����: ");
	print_longnumber( number2 );
	printf("\n");

	for( i = LONGNUMBER_LENGTH-1; i >= 0; i -= 1 )
	{
		number_result[i] = (number1[i]-'0') + (number2[i]-'0');
		if( number_result[i] > 10 ) { number_result[i-1] += 1; number_result[i] = (number_result[i]-10); }
		number_result[i] += '0';
	}
	
	printf("���ϸ�: ");
	print_longnumber( number_result );
	printf("\n");

	return 0;
}

void print_longnumber( char *n )
{
	int i;
	int isPrinted = 0;
	for( i = 0; i < LONGNUMBER_LENGTH; i += 1 )
	{
		if( n[i] == '0' && isPrinted == 0 ) continue;
		printf("%c", n[i]);
		isPrinted += 1;
	}
}
