#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <windows.h>

typedef struct _tnode {
	char * data;

	struct _tnode *parent;
	struct _tnode **childs;
	int childsCount;
} TNODE;

TNODE *treeInit( char * data );
void appendChild( TNODE *parent, TNODE *child );
TNODE *treeSplit( TNODE *node );
void treePrint( TNODE *node, int depth );
TNODE *treeSearch( TNODE *root, char * data );
void exploreDirectory(TNODE * node, char * dir, int depth)
{
	int i;
	char buf[500]={0,};
	
	void * handle;
	WIN32_FIND_DATA wfd;

	for(i=0;i<depth;i++)
	{
		printf("\t");
	}
	node->data=dir;
	printf("%s",node->data);
	handle=FindFirstFile("C:\\",&wfd);
	
	do
	{
		if(!strcmp(wfd.cFileName,".") || !strcmp(wfd.cFileName,".."))
			continue;

		printf("%s",wfd.cFileName);
		sprintf(buf,"%s\\%s\\",dir,wfd.cFileName);
		
		for(i=0;i<node->childsCount;i++)
		{
			exploreDirectory(node->childs[i],buf,depth+1);
		}

	}while(FindNextFile(handle,&wfd));

	
}
int main( void )
{
	TNODE *rootNode, *c1, *c2, *c3, *c4, *c5, *c6, *c7, *tempnode;
	char buf[500];
	char startPath[30]="C:";
	char searchPath[2000];
	char * dir = (char*)malloc(sizeof(char)*100);
	WIN32_FIND_DATA wfd;
	void * handle;

	rootNode=treeInit("C:\\");
	c1=treeInit("Windows");
	c2=treeInit("Intel");
	appendChild(rootNode,c1);
	appendChild(rootNode,c2);
	treePrint(rootNode,0);

	return 0;
}

TNODE *treeInit( char* data )
{
	TNODE * n = (TNODE*)malloc(sizeof(TNODE));
	memset(n, 0, sizeof(TNODE));
	n->data=data;

	return n;
}

void appendChild( TNODE *parent, TNODE *child )
{
	TNODE ** temp;
	if(parent->childsCount==0)
	{
		parent->childs=(TNODE**)malloc(sizeof(TNODE*)*1);

	}
	else
	{
		temp=parent->childs;
		parent->childs=(TNODE**)malloc(sizeof(TNODE*)*(parent->childsCount+1));
		memset(parent->childs, 0, sizeof(TNODE*)*(parent->childsCount+1) );
		memcpy(parent->childs, temp, sizeof(TNODE*)*(parent->childsCount));
		free(temp);
	}

	child->parent=parent;
	parent->childs[parent->childsCount]=child;
	parent->childsCount+=1;

}
TNODE *treeSplit( TNODE *node )
{
	TNODE * parent=node->parent;
	TNODE ** temp;
	int i;

	if(node->parent==NULL)
		return NULL;

	for(i=0;i<parent->childsCount;i++)
	{
		if(node==parent->childs[i])
			break;
	}

	temp=parent->childs;
	parent->childs=(TNODE**)malloc(sizeof(TNODE*)*(parent->childsCount-1));
	memcpy(parent->childs,temp,sizeof(TNODE*)*i);
	memcpy(parent->childs+i,temp+i+1,sizeof(TNODE*)*(parent->childsCount-i-1));
	free(temp);

	parent->childsCount-=1;
	node->parent=NULL;

	return node;
}

void treePrint( TNODE *node, int depth )
{
	int i;

	for(i=0;i<depth;i++)
		printf("\t");
	
	printf("Data of Node: %s\n",node->data);
	for(i=0;i<node->childsCount;i++)
	{
		treePrint(node->childs[i],depth+1);
	}

}
TNODE *treeSearch( TNODE *root, char* data )
{
	TNODE * p;
	int i;

	if(root->childsCount==0 && root->data!=data)
		return NULL;
	if(root->data==data)
		return root;

	for(i=0;i<root->childsCount;i++)
	{
		p=treeSearch(root->childs[i],data);
		if(p== NULL )
			continue;
		else return p;
	}

	return NULL;
}

/*
for(i = 0; i < root->childsCount; i+=1)
	{
		p = treeSearch(root->childs[i], data);
		if( p == NULL ) continue;
		else return p;
	}
	return NULL;
}*/