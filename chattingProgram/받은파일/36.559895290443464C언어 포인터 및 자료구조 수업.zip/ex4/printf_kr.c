
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <stdarg.h>
#define w s

int printf_kr(char * str, ... )
{
	int cnt=0;

	va_list va;
	va_start(va,str);
	
	cnt=vprintf(str,va);
	va_end(va);
	
	return cnt;
}
char * my_printf(char * cptr, ... )
{
	int cnt=0;
	char * a;
	va_list va;
	va_start(va,cptr);
	
	vprintf(cptr,va);
	(char*)va=(char*)va-4;
	a=va;
	va_end(va);

	return a;
}
char * func(char * money, char * temp, int a)
{
	int i,j;

		for(i=0;i<strlen(money)+a;i++)
		{
				
			if(i==0)
				temp=malloc(strlen(money)+1+a);
			if(i==strlen(money)-3)
			{
				temp[i]=',';
			}
			else
			{
				temp[i]=money[j];
				j++;
			}
		}
			
	temp[i]='\0';

	return temp;
}
int main(void)
{
	int num=0;
	int i=0;
	int j=0;
	int k=0;
	char money[100];
	char * temp;
	int a=0;
	gets(money);

	if(strlen(money)>=1 && strlen(money)<=3)
	{
			for(i=0;i<strlen(money);i++)
			{
				
				if(i==0)
					temp=malloc(strlen(money)+1);
			
			}
			strcpy(temp,money);
	}

	else if(strlen(money)>=4 && strlen(money)<=6)
	{

	for(i=0;i<strlen(money)+1;i++)
		{
			if(i==0)
				temp=malloc(strlen(money)+1+1);
			if(i==strlen(money)-3)
			{
				temp[i]=',';
			}
			else
			{
				temp[i]=money[j];
				j++;
			}

		}
	}

	else if(strlen(money)>=7 && strlen(money)<=9)
	{

		for(i=0;i<strlen(money)+2;i++)
		{
			if(i==0)
				temp=malloc(strlen(money)+1+2);
			if(i==strlen(money)-6 || i==strlen(money)-2)
			{
				temp[i]=',';
			}
			else
			{
				temp[i]=money[j];
				j++;
			}

		}
	}
	
	temp[i]='\0';

	puts(temp);
	printf_kr( "%s��! %d�� ��ǰ�� ���� ȯ�� %f�� �����Ͽ� ����Ͻ� �ݾ��� �� %s�� �Դϴ�.", "ȫ�浿", 5, 1054.82, a);
}
