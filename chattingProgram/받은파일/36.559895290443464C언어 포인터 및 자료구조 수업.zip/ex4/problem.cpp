/*
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int ACDSort(int a, int b)
{
	if(a>b)
	{
		return 1;
	}
	else
		return 0;
}
void Bubblesort(int arr[], int len, int (*compare)(int,int))
{
	int i,j;
	int temp=0;

	for(i=0;i<len-1;i++)
	{
		for(j=0;j<len-1-i;j++)
		{
			if(compare(arr[j],arr[j+1]))
			{
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
}
int main(void)
{
	int arr[10];
	int i;

	for(i=0;i<10;i++)
	{
		printf("%d��° ���� �Է�: ",i+1);
		scanf("%d",&arr[i]);
	}

	Bubblesort(arr,sizeof(arr)/sizeof(int),ACDSort);
	
	for(i=0;i<10;i++)
	{
		printf("%d ",arr[i]);

	}

	return 0;
}

	

*/