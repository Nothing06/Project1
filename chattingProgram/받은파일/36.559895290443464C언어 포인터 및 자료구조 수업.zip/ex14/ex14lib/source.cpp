#include <windows.h>
#include <stdio.h>

extern "C" _declspec(dllexport) int sum1( int a, int b );
int sum2( int a, int b );

BOOL WINAPI DllMain( HINSTANCE hInstDLL, DWORD fdwReason, LPVOID lpvReserved )
{
	printf( "DLL �� �ε�Ǿ���.\n" );
	return 1;
}

int sum1( int a, int b )
{
	return sum2(a,b);
}

int sum2( int a, int b )
{
	return a+b;
}
