#define _CRT_SECURE_NO_WARNINGS
#include"common.h"
#include"customer.h"
#include"screenout.h"
ClientData Datalist[100];
int numOfData=0;
void InputData(void)
{
	int i;
	ClientData * pdata=(ClientData*)malloc(sizeof(ClientData));

	fputs("�̸�: ",stdout);
	fgets(pdata->name,30,stdin);
	fputs("����: ",stdout);
	scanf("%d",&(pdata->age));
	fflush(stdin);
	fputs("�ֹε�Ϲ�ȣ: ",stdout);
	fgets(pdata->iden,30,stdin);
	fputs("�� ��: ",stdout);
	fgets(pdata->address,50,stdin);
	fputs("��ȭ��ȣ: ",stdout);
	fgets(pdata->phone,30,stdin);
	fputs("�������: ",stdout);
	scanf("%d %d %d",&(pdata->year),&(pdata->month),&(pdata->day));
	fflush(stdin);
	
	for(i=0;i<numOfData;i++)
	{
		if(!strcmp(pdata->name,Datalist[i].name) && !strcmp(pdata->iden,Datalist[i].phone))
		{
			fputs("�̹� ��ϵ� �����Դϴ�.",stdout);
			free(pdata);
			getchar();
			fflush(stdin);
			return;
		}
	}
	Datalist[numOfData++]=*pdata;
	fputs("�Է� �Ϸ�",stdout);
	getchar();
	fflush(stdin);
	StoreDataToFile();
	return;
}
void ChangeData(void)
{
		char name[30];
		char iden[30];
		int age=0;
		char address[50];
		char phone[30];
		int year=0;
		int month=0;
		int day=0;
		int num=0;
		int i;

		fputs("������ ���������� �̸� �Է�: ",stdout);
		fgets(name,30,stdin);
		fputs("������ ���������� �ֹι�ȣ �Է�: ",stdout);
		fgets(iden,30,stdin);
		fflush(stdin);

		for(i=0;i<numOfData;i++)
		{
			if(!strcmp(name,Datalist[i].name) && !strcmp(iden,Datalist[i].iden))
			{
				break;
			}
			else
				continue;
		}
			
		if(strcmp(name,Datalist[i].name)!=0 ||  strcmp(iden,Datalist[i].iden) !=0)
		{
			printf("����� ã���������ϴ�.\n");
			getchar();
			fflush(stdin);
			return;
		}
			printf("\n\n");
	
		while(1)
		{
		printf("�ٲ� ���� ����(��ȣ�� �Է��ض�)\n");
		printf("1. �̸� \n ");
		printf("2. ���� \n");
		fputs("3.�ֹε�Ϲ�ȣ \n",stdout);
		fputs("4.�� �� \n",stdout);
		fputs("5.��ȭ��ȣ\n ",stdout);
		fputs("6. �׸��ٲܲ���\n",stdout);
		fputs(">>����: ",stdout);
		scanf("%d",&num);
		fflush(stdin);


		switch(num)
		{
		case 1:
			strcpy(Datalist[i].name,name);
			break;
		case 2:
			printf("������ ���̴�? ");
			scanf("%d",&age);
			fflush(stdin);
			Datalist[i].age=age;
			break;
		case 3:
			fputs("������ �ֹ��Է�: ",stdout);
			fgets(iden,30,stdin);
			strcpy(Datalist[i].iden,iden);
			break;
		case 4:
			fputs("������ �ּ��Է�: ",stdout);
			fgets(address,50,stdin);
			strcpy(Datalist[i].address,address);
			fflush(stdin);
			break;
		case 5:
			fputs("������ �����Է�: ",stdout);
			fgets(phone,30,stdin);
			strcpy(Datalist[i].phone,phone);
			fflush(stdin);
			break;
		case 6:
			fputs("����׸�",stdout);
			break;

		}
		if(num==6)
		{
			printf("�׸��ٲ۴�");
			break;
		}
		

		fputs("����Ϸ�\n",stdout);
		ShowInfobyptr(&Datalist[i]);
	}
	
		getchar();
		fflush(stdin);
		StoreDataToFile();
		return;

}
void DeleteData(void)
{
	char delname[30];
	char deliden[30];
	int i,j;

	fgets(delname,30,stdin);
	fgets(deliden,30,stdin);

	for(i=0;i<numOfData;i++)
	{
		if(!strcmp(delname,Datalist[i].name) && !strcmp(deliden,Datalist[i].iden))
		{
			for(j=i;j<numOfData-1;j++)
			{
				Datalist[j]=Datalist[j+1];
			}
		}
	}
	numOfData--;
	puts("�����Ϸ�");
	getchar();
	fflush(stdin);
	StoreDataToFile();
}
void ShowAllData(void)
{
	int i;

	for(i=0;i<numOfData;i++)
	{
		ShowInfobyptr(&Datalist[i]);
	}
	
	fputs("��¿Ϸ�",stdout);
	getchar();
	fflush(stdin);
	return;
}
void SearchData(void)
{
	char name[30];
	char iden[30];
	int i;
	fputs("�̸�: ",stdout);
	fgets(name,30,stdin);
	fputs("�ֹ�: ",stdout);
	fgets(iden,30,stdin);

	for(i=0;i<numOfData; i++)
	{
		if(!strcmp(name,Datalist[i].name) && !strcmp(iden,Datalist[i].iden))
		{
			ShowInfobyptr(&Datalist[i]);
			fputs("�˻��Ϸ�",stdout);
			getchar();
			fflush(stdin);
			return;
		}
	}
}
void FreeData(void)
{
	int i;

	for(i=0;i<numOfData;i++)
	{
		free(&Datalist[i]);
	}
}
void StoreDataToFile(void)
{
	FILE * fp=fopen("customer.dat","wt");
	int i;

	fwrite(&numOfData,sizeof(int),1,fp);
	for(i=0;i<numOfData;i++)
	{
		fputs(Datalist[i].name,fp);
		fwrite(&Datalist[i].year,sizeof(int),1,fp);
		fwrite(&Datalist[i].month,sizeof(int),1,fp);
		fwrite(&Datalist[i].day,sizeof(int),1,fp);
		fputc('\n',fp);
		fputs(Datalist[i].address,fp);
		fputs(Datalist[i].iden,fp);
		fputs(Datalist[i].phone,fp);
		fwrite(&Datalist[i].age,sizeof(int),1,fp);
		fputc('\n',fp);
	}
	fclose(fp);

}
void LoadDataFromFile(void)
{
	FILE * fp=fopen("customer.dat","rt");
	int i;

	if(fp==NULL)
	{
		printf("���ϰ������\n");
		return;
	}

	fread(&numOfData,sizeof(int),1,fp);
	for(i=0;i<numOfData;i++)
	{
		fgets(Datalist[i].name,30,fp);
		fread(&Datalist[i].year,sizeof(int),1,fp);
		fread(&Datalist[i].month,sizeof(int),1,fp);
		fread(&Datalist[i].day,sizeof(int),1,fp);
		fgetc(fp);
		fgets(Datalist[i].address,50,fp);
		fgets(Datalist[i].iden,30,fp);
		fgets(Datalist[i].phone,30,fp);
		fread(&Datalist[i].age,sizeof(int),1,fp);
		fgetc(fp);
	}
	fclose(fp);

}
