#ifndef _COMMON_H__

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#endif