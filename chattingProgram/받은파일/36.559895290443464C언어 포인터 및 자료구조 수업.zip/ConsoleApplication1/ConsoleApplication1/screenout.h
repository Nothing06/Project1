#ifndef __SCREENOUT_H__
#define __SCREENOUT_H__
#include"customer.h"

void ShowInfobyptr(ClientData * ptr);
void ShowMenu(void);

#endif