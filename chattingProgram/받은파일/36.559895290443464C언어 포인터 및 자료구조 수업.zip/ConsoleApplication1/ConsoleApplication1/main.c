#define _CRT_SECURE_NO_WARNINGS
#include"common.h"
#include"customer.h"
#include"screenout.h"

int main(void)
{
	int num=0;
	LoadDataFromFile();
	while(1)
	{
		ShowMenu();
		scanf("%d",&num);
		fflush(stdin);

		switch(num)
		{
		case 1:
			InputData();
			break;
		case 2:
			ChangeData();
			break;
		case 3:
			DeleteData();
			break;
		case 4:
			ShowAllData();
			break;
		case 5:
			SearchData();
			break;
		case 6:
			break;
		}
		if(num==6)
		{
			StoreDataToFile();
			printf("���α׷������մϴ�.");
			break;
		}
	}
}