#ifndef _CUSTOMER_H__
#define _CUSTOMER_H__

typedef struct customer_
{
	char name[30];
	int year;
	int month;
	int day;
	int age;
	char address[50];
	char phone[30];
	char iden[30];
}ClientData;
void InputData(void);
void ChangeData(void);
void DeleteData(void);
void ShowAllData(void);
void SearchData(void);
void FreeData(void);
void StoreDataToFile(void);
void LoadDataFromFile(void);
#endif