#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
main()
{
	int x=0;
	int y=0;
	int z=0;
	int i=0;
	int shorter=0;
	int middle=0;
	int longer=0;
	printf("x,y,z �Է�: ");
	scanf("%d %d %d",&x,&y,&z);

	shorter= (x < y ? x : y);
	shorter= shorter < z ? shorter : z;

	longer= (x > y ? x : y);
	longer= longer > z ? longer : z;

	if(x<=y && y<=z)
	{
		middle=y;
	}
	
	else if(x<=z && z<=y)
	{
		middle=z;
	}

	else if(y<=x && x<=z)
	{
		middle=x;
	}
	
	else if(y<=z && z<=x)
	{
		middle=z;
	}
	
	else if(z<=x && x<=y)
	{
		middle=x;
	}

	else if(z<=y && y<=x)
	{
		middle=y;
	}

	
	if(longer*longer > (middle * middle) + (shorter * shorter))
		printf("�а��ﰢ���̴�.\n");
	else if(longer*longer == middle * middle + shorter * shorter)
		printf("�����ﰢ���̴�.\n");
	else if(longer*longer == middle * middle + shorter * shorter)
		printf("�����ﰢ���̴�.\n");
	else if(longer==middle && middle==shorter)
		printf("���ﰢ���̴�.\n");
}


