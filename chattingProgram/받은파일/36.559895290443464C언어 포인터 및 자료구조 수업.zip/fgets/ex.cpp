

#include<stdio.h>
int main( void )
{
	char str[5];

	fgets(str,10,stdin);
	
	puts(str);
	return 0;
}