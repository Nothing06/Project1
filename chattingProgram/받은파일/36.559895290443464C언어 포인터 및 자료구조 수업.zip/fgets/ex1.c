
/*
#include<stdio.h>
int main( void )
{
	char str[5];

	gets(str);
	puts(str);
	return 0;
}*/