#include<stdio.h>
int main(void)
{
	
	int i;
	int j;

	for(i=0;i<6;i++)
	{	
		if(i==5)
		{
			for(j=0;j<5;j++)
				printf("��");
			break;
		}
		printf("��\n");
	}

	printf("\n\n");

	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			if((i>=1 && i<=3) && (j>=1 && j<=3))
			{
				printf("  ");
				continue;
			}
			printf("��");
		}
		printf("\n");
	}

	printf("\n");

	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			if((i>=0 && i<=2)&& (j>=1 && j<=3))
			{
				printf("  ");
				continue;
			}
			else if((i==3) && (j%2==0))
			{
				printf("  ");
				continue;
			}
			else if(i==4 && j!=2)
			{
				printf("  ");
				continue;
			}
			printf("��");
		}
		printf("\n");
	}

	printf("\n");
	
	for(i=0;i<5;i++)
	{	
		for(j=0;j<5;j++)
		{
			if((i==1 || i==3 ) && (j>=1 && j<=4))
			{
				printf("  ");
				continue;
			}
			printf("��");
		}
		printf("\n");
	}

}
