#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char * numbercomma(int money);
int main( void )
{	
	int money=0;

	fputs("�� �Է�: ",stdout);
	scanf("%d",&money);

	printf("%d -> %s\n",money, numbercomma(money));

	return 0;
}
char * numbercomma(int money)
{
	char buf[100];
	int commacnt,i,numberLength,printedcommacnt;
	int t=0;
	char * result;
	printedcommacnt=0;
	sprintf(buf,"%d",money);
	numberLength=strlen(buf);
	commacnt=strlen(buf)/3;
	if(commacnt%3==0)
		commacnt-=1;

	result=(char*)malloc(strlen(buf)+1+commacnt);
	memset( result , 0, strlen(buf)+1+commacnt);
	for(i=numberLength-1;i>=0;i--)
	{
		result[i+(commacnt-printedcommacnt)]=buf[i];
		t+=1;
		if(t%3==0)
		{
			printedcommacnt+=1;
			result[i+commacnt-printedcommacnt]=',';
		}
	}

	return result;
}
