















































#include <stdio.h>
#include <string.h>
#include <malloc.h>

typedef struct _tnode {
	int data;

	struct _tnode *parent;
	struct _tnode **childs;
	int childsCount;
} TNODE;

TNODE *treeInit( int data );
void appendChild( TNODE *parent, TNODE *child );
TNODE *treeSplit( TNODE *node );
void treePrint( TNODE *node, int depth );
TNODE *treeSearch( TNODE *root, int data );

int main( void )
{
	TNODE *rootNode, *c1, *c2, *c3, *c4, *c5, *c6, *c7, *tempnode;
	rootNode = treeInit(10);
	
	c1 = treeInit(11);
	c2 = treeInit(12);
	appendChild( rootNode, c1 );
	appendChild( rootNode, c2 );

	c3 = treeInit(21);
	c4 = treeInit(22);
	appendChild( c2, c3 );
	appendChild( c2, c4 );

	c5 = treeInit(31);
	c6 = treeInit(32);
	appendChild( c3, c5 );
	appendChild( c3, c6 );

	c7 = treeInit(41);
	appendChild( c5, c7 );

	printf("��ü Ʈ�� ����\n");
	treePrint(rootNode, 0);

	printf("\n\n");

	printf("21�� ��� ã��\n");
	tempnode = treeSearch(rootNode, 21);
	if(tempnode == NULL) printf("ã�� ����\n");
	else printf("ã����\n");

	printf("\n\n");

	printf("21�� ��带 �������� �� Ʈ������\n");
	treePrint(tempnode, 0);

	printf("\n\n");

	printf("21�� ��带 Ʈ������ �и��� ���� ��ü Ʈ������\n");
	treeSplit(tempnode);
	treePrint(rootNode, 0);
	
	
	return 0;
}


TNODE *treeInit( int data )
{
	TNODE *n = (TNODE*)malloc(sizeof(TNODE));
	memset(n, 0, sizeof(TNODE));
	n->data = data;
	return n;
}

TNODE *treeSearch( TNODE *root, int data )
{
	int i;
	TNODE *p;
	if(root->data == data) return root;
	if(root->data != data && root->childsCount == 0) return NULL;

	for(i = 0; i < root->childsCount; i+=1)
	{
		p = treeSearch(root->childs[i], data);
		if( p == NULL ) continue;
		else return p;
	}
	return NULL;
}

void treePrint( TNODE *node, int depth )
{
	int i;
	for(i = 0; i < depth; i+=1)
		printf("\t");
	printf("����� ������: %d\n", node->data);

	for(i = 0; i < node->childsCount; i+=1)
		treePrint(node->childs[i], depth+1);
}

void appendChild( TNODE *parent, TNODE *child )
{
	if(parent->childsCount==0)
	{
		parent->childs = (TNODE**)malloc( sizeof(TNODE*) * 1 );
	}
	else
	{
		TNODE **temp;
		temp = parent->childs;
		parent->childs = (TNODE**)malloc( sizeof(TNODE*) * (parent->childsCount+1) );
		memcpy( parent->childs, temp, sizeof(TNODE*)*parent->childsCount );
		free( temp );
	}
	child->parent = parent;
	parent->childs[parent->childsCount] = child;
	parent->childsCount += 1;
}

TNODE *treeSplit( TNODE *node )
{
	TNODE *parent = node->parent;
	TNODE **temp;
	int i;
	if(node->parent==NULL) return NULL;

	for(i = 0; i < parent->childsCount; i += 1)
		if(parent->childs[i] == node) break;

	temp = parent->childs;
	parent->childs = (TNODE**)malloc( sizeof(TNODE*)*(parent->childsCount-1) );
	memcpy( parent->childs, temp, sizeof(TNODE*)*i );
	memcpy( parent->childs+i, temp+i+1, sizeof(TNODE*)*(parent->childsCount-i-1) );
	parent->childsCount -= 1;
	free( temp );

	node->parent = NULL;
	return node;
}
