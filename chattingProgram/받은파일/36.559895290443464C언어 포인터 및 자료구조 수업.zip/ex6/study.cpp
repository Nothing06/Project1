#include<stdio.h>
#include<stdlib.h>
#include<windows.h>

void exploreDirectory( char *dir, int depth );

int main ( void )
{
	printf("C:\\Intel\n\t");
	exploreDirectory( "C:\\Intel", 0 );

	/*
	WIN32_FIND_DATA wfd;
	WIN32_FIND_DATA wfd2;
	WIN32_FIND_DATA wfd3;
	WIN32_FIND_DATA wfd4;
	void * handle;
	void * handle2;
	void * handle3;
	void * handle4;
	char startPath[]="C:";
	char searchPath[25];
	char searchPath2[50];
	char searchPath3[1000];

	sprintf(searchPath, "%s\\*.*", startPath);
	handle = FindFirstFile(searchPath, &wfd);
	
	printf("%s\n",startPath);

	do{
		
		fprintf(stdout,"\t%s\n",wfd.cFileName);

		sprintf(searchPath2, "%s\\%s\\*.*",startPath, wfd.cFileName);
		handle2=FindFirstFile(searchPath2,&wfd2);

		do
		{
			fprintf(stdout,"\t\t%s\n",wfd2.cFileName);
			sprintf(searchPath2, "%s\\%s\\%s\\*.*", startPath, wfd.cFileName, wfd2.cFileName);
			handle3=FindFirstFile(searchPath2, &wfd3);
			do
			{
				
				/*sprintf(searchPath3, "%s\\%s\\%s\\%s\\*.*",startPath, wfd.cFileName, wfd2.cFileName, wfd3.cFileName);
				handle4=FindFirstFile(searchPath2, &wfd4);
				do
				{
					if(wfd4.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
					fprintf(stdout,"\t\t\t\t%s\n",wfd4.cFileName);
				}while(FindNextFile(handle4,&wfd4));*/
	/*
			if(wfd3.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				fprintf(stdout,"\t\t\t%s\n",wfd3.cFileName);
			}while(FindNextFile(handle3, &wfd3));
				
		}while(FindNextFile(handle2,&wfd2));

	}while(FindNextFile(handle,&wfd));

	FindClose(handle);
	FindClose(handle2);
	FindClose(handle3);
//	FindClose(handle4);
	*/
	return 0;
}

void exploreDirectory( char *dir, int depth )
{
	WIN32_FIND_DATA wfd;
	void *handle;
	int j;
	char searchPath[255] = { 0, };
	sprintf(searchPath, "%s\\*.*", dir);

	handle = FindFirstFile(searchPath, &wfd);
	do
	{
		if(strcmp(wfd.cFileName, ".") == 0) continue;
		if(strcmp(wfd.cFileName, "..") == 0) continue;

		if(wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			char nextSearchPath[255] = { 0, };

			printf("%s\n",wfd.cFileName);

			for(j=0;j<depth+2;j++)printf("\t");
			
			sprintf( nextSearchPath, "%s\\%s", dir, wfd.cFileName);
			exploreDirectory( nextSearchPath, depth+1 );
		}
		else
		{
			int i;
			for(i = 0; i < depth+2; i += 1) printf("\t");
			printf("%s\n", wfd.cFileName);
		}
	} while( FindNextFile(handle, &wfd) );
}