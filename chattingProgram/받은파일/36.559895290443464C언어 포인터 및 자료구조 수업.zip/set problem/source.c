/* Begin of Program */


#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <tchar.h>
#define TC TCHAR
#define TI int
#define BL 1024
#define W while
#define S static
#define P _tprintf
#define F FILE
#define G _fgetts
#define FO _tfopen
#define FC fclose
#define FR for
#define R return
#define SC _stscanf
#define E else
#define SI stdin
#define SL _tcslen
#define M _tmain
#define MC calloc
#define SO sizeof


       TI*GS(                     TC c,TI*pl,F*f)       {S TI  t=0;           TC 
     b[BL] ={0,}                       ;TC*p            =b;TI  *s=0           ,l
    =0,sl   =0;t++                  ;if(f  ==SI)        P(_T(  "%c:"          ),c);G(b,BL,f);
   if(t!=     1&&f!=               SI)G(    b,BL,  f);b[SL(b)  -1]=           0;W(*p!=0)if (*p++
  ==' ')      l+=1;p             =b;s=(      TI*)  MC(l,SO(TI  ));W
(*p!=0)        {if(SC           (p,_T(       "%d") ,s+sl))if(  s[sl]         !=0)sl++;W(*p!=' '&&
                                                        *p!=0  )p++;
if(*p!=0)p++;}*pl=sl;                                   R s;}  void           SS(
TI*s,TI l){TI i,m;do{                                   m=0;   for(           i=0
         ;i<                                                                  l-1;i++)if(s[i]>s[i
   +1]){s[i]=s[i]^
              s[i+
              1];s




              [i+1]=                       s[i]^s                   [i+1];s[i]=s[i]^s[i+1];
            m++;}  }W(                  m!=0)   ;R;}                                  TI M(
           TI ac,   TC*                ag[])      {TI               *s1,*s2,s1l=0,s2l=0,l1,
          l2,*ps     ,psl            =0,n=0;       if(              ac==2)
        {F*f=         FO(           ag[1],          _T("r"          ));if(f==0){P(_T("Cann"
       "ot R"         "ead"        " Fil"            "e %s"         "\n"),ag[1]);R 0;}s1=GS
                                                                              ('A',
      &s1l,f);s2=GS('B',&s2l,    f);FC(f);}E{P(_T("This pro"    "gram also be executed by followi"




"ng command:\n\t%s [filename]\n\nExample:\n\t%s sets.txt\n\nInput file not given, so we are going"
"to use console input.\n\n"),ag[0],ag[0]);s1=GS('A',&s1l,SI);s2=GS('B',&s2l,SI);}P(_T("Intersecti"
"on of 2 sets: "));FR(l1=0;l1<s1l;l1++)FR(l2=0;l2<s2l;l2++)if(s1[l1]==s2[l2])psl++;ps=(TI*)calloc
(psl,sizeof(TI));FR(l1=0;l1<s1l;l1++)FR(l2=0;l2<s2l;l2++)if(s1[l1]==s2[l2])ps[n++]=s1[l1];SS(ps,psl);
FR(l1=0;l1<psl;l1++)P(_T("%d "),ps[l1]);free(ps);psl=0;n=0;P(_T("\n"));P(_T("Union of 2 sets: "));
FR(l1=0;l1<s1l;l1++)psl++;FR(l2=0;l2<s2l;l2++){TI f=0;FR(l1=0;l1<s1l;l1++)if(s1[l1]==s2[l2])f=1;if(!f)
psl++;}ps=(TI*)calloc(psl,sizeof(TI));FR(l1=0;l1<s1l;l1++)ps[n++]=s1[l1];FR(l2=0;l2<s2l;l2++){TI f=0;
FR(l1=0;l1<s1l;l1++)if(s1[l1]==s2[l2])f=1;if(!f)ps[n++]=s2[l2];}SS(ps,psl);FR(l1=0;l1<psl;l1++)P(_T
("%d "),ps[l1]);free(ps);psl=0;n=0;P(_T("\n"));R 0;}


/* End of Program */