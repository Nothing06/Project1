#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>

#define TYPE_DIR		1
#define TYPE_FILE		0

typedef struct _tnode
{
	char *filename;
	int type; // 0=���� 1=���丮

	struct _tnode *parent;
	struct _tnode **childs;
	int childsCount;
} TNODE;

TNODE *treeInit( char *drivename, int type );
void appendChild( TNODE *parent, TNODE *child );
void searchNode( TNODE *node, char *keyword, int needPrint, int depth, char *parentPath ); // needPrint=0 �̸� ȭ�鿡 ��� ����, 1�̸� �����

void listFiles( char *path, TNODE *parent );

TNODE *drive = NULL;

int main( void )
{
	char drivename[2];
	char keyword[512] = { 0, };
	memset(drivename, 0, 2);
	printf("������ �ϴ� ����̺� �̸��� �빮�ڷ� �Է��ϼ���: ");
	scanf("%c", &drivename); fflush(stdin);

	printf("��ũ Ž�� ����...");
	drive = treeInit(drivename, TYPE_DIR);
	listFiles(drivename, drive);
	printf(" ...�Ϸ�\n");

	while(1)
	{
		printf("ã���� �ϴ� ���� Ȥ�� ���丮 ���� �Է��ϼ���: ");
		scanf("%s", keyword);
		if(strlen(keyword)==1 && keyword[0]=='X') break;
		searchNode(drive, keyword, 1, 0, NULL);
	}

	return 0;
}

void listFiles( char *path, TNODE *parent )
{
	char path1[512] = { 0, };
	char path2[512] = { 0, };
	WIN32_FIND_DATA wfd;
	void *handle;
	TNODE *node = NULL;

	if(strlen(path)==1)
		sprintf( path1, "%s:", path);
	else
		sprintf( path1, "%s", path);
	sprintf( path2, "%s\\*.*", path1);
	
	memset(&wfd, 0, sizeof(WIN32_FIND_DATA));
	handle = FindFirstFile( path2, &wfd );
	do
	{
		if(strcmp(wfd.cFileName,".")==0 || strcmp(wfd.cFileName,"..")==0) continue;
		if(wfd.cFileName[0]=='$') continue;
		if(wfd.dwFileAttributes&FILE_ATTRIBUTE_SYSTEM) continue;
		if(wfd.dwFileAttributes&FILE_ATTRIBUTE_HIDDEN) continue;
		if(wfd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)
		{
			char childPath[512] = { 0, };
			node = treeInit(wfd.cFileName, TYPE_DIR);
			appendChild(parent, node);
			sprintf(childPath, "%s\\%s", path1, wfd.cFileName);
			listFiles(childPath, node);
		}
		else
		{
			node = treeInit(wfd.cFileName, TYPE_FILE);
			appendChild(parent, node);
		}

		memset(&wfd, 0, sizeof(WIN32_FIND_DATA));
	} while( FindNextFile(handle, &wfd) );
	FindClose(handle);
}

TNODE *treeInit( char *drivename, int type )
{
	TNODE *n = (TNODE*)malloc(sizeof(TNODE));
	memset(n, 0, sizeof(TNODE));
	n->filename = (char*)malloc( strlen(drivename)+1 );
	strcpy(n->filename, drivename);
	n->type = type;
	return n;
}

void appendChild( TNODE *parent, TNODE *child )
{
	if(parent->childsCount==0)
	{
		parent->childs = (TNODE**)malloc( sizeof(TNODE*) * 1 );
	}
	else
	{
		TNODE **temp;
		temp = parent->childs;
		parent->childs = (TNODE**)malloc( sizeof(TNODE*) * (parent->childsCount+1) );
		memcpy( parent->childs, temp, sizeof(TNODE*)*parent->childsCount );
		free( temp );
	}
	child->parent = parent;
	parent->childs[parent->childsCount] = child;
	parent->childsCount += 1;
}

void searchNode( TNODE *node, char *keyword, int needPrint, int depth, char *parentPath )
{
	int i;
	if( strcmp(node->filename,keyword)==0 )
	{
		if( needPrint )
		{
			if( depth == 0 )
				printf("%s:", node->filename);
			else
			{
				printf("%s\\%s", parentPath, node->filename);
			}
			if(node->type==1)
				printf("\\\n");
			else
				printf("\n");
		}
	}

	for(i = 0; i < node->childsCount; i++)
	{
		char myPath[512] = { 0, };
		if(depth==0) sprintf(myPath, "%s:", node->filename);
		else sprintf(myPath, "%s\\%s", parentPath, node->filename);
		searchNode(node->childs[i], keyword, needPrint, depth+1, myPath);
	}
}
