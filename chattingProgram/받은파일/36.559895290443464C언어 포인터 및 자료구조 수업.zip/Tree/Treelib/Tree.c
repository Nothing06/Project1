#include"Tree.h"

TNODE *treeInit( char * data )
{
	TNODE *n = (TNODE*)malloc(sizeof(TNODE));
	memset(n, 0, sizeof(TNODE));
	strcpy(n->data, data);
	return n;
}

TNODE *treeSearch( TNODE *root, char * data )
{
	int i;
	TNODE *p;
	if(!strcmp(root->data,data)) return root;
	if(strcmp(root->data,data) && root->childsCount == 0) return NULL;

	for(i = 0; i < root->childsCount; i+=1)
	{
		p = treeSearch(root->childs[i], data);
		if( p == NULL ) continue;
		else return p;
	}
	return NULL;
}

void treePrint( TNODE *node, int depth )
{
	int i;
	for(i = 0; i < depth; i+=1)
		printf("\t");
	printf("����� ������: %s\n", node->data);

	for(i = 0; i < node->childsCount; i+=1)
		treePrint(node->childs[i], depth+1);
}

void appendChild( TNODE *parent, TNODE *child )
{
	if(parent->childsCount==0)
	{
		parent->childs = (TNODE**)malloc( sizeof(TNODE*) * 1 );
	}
	else
	{
		TNODE **temp;
		temp = parent->childs;
		parent->childs = (TNODE**)malloc( sizeof(TNODE*) * (parent->childsCount+1) );
		memcpy( parent->childs, temp, sizeof(TNODE*)*parent->childsCount );
		free( temp );
	}
	child->parent = parent;
	parent->childs[parent->childsCount] = child;
	parent->childsCount += 1;
}

TNODE *treeSplit( TNODE *node )
{
	TNODE *parent = node->parent;
	TNODE **temp;
	int i;
	if(node->parent==NULL) return NULL;

	for(i = 0; i < parent->childsCount; i += 1)
		if(parent->childs[i] == node) break;

	temp = parent->childs;
	parent->childs = (TNODE**)malloc( sizeof(TNODE*)*(parent->childsCount-1) );
	memcpy( parent->childs, temp, sizeof(TNODE*)*i );
	memcpy( parent->childs+i, temp+i+1, sizeof(TNODE*)*(parent->childsCount-i-1) );
	parent->childsCount -= 1;
	free( temp );

	node->parent = NULL;
	return node;
}
