#ifndef __TREE_H__
#define __TREE_H__

#include <stdio.h>
#include <string.h>
#include <malloc.h>

typedef struct _tnode {
	char * data;

	struct _tnode *parent;
	struct _tnode **childs;
	int childsCount;
} TNODE;

TNODE *treeInit( char * data );
void appendChild( TNODE *parent, TNODE *child );
TNODE *treeSplit( TNODE *node );
void treePrint( TNODE *node, int depth );
TNODE *treeSearch( TNODE *root, char* data );

#endif