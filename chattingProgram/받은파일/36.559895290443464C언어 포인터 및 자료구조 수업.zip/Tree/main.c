#include"Treelib\\Tree.h"

#pragma comment(lib, "Treelib\\Debug\\Treelib.lib")
void exploreDirectory(TNODE * node, int depth)
{
	int i;
	char buf[100];
	
	for(i=0;i<depth;i++)
		printf("\t");

	printf("%s\n",node->data);
	for(i=0;i<node->childsCount;i++)
	{
		exploreDirectory(node->childs[i] , depth+1);
	}
	
}
int main( void )
{
	TNODE *rootNode, *c1, *c2, *c3, *c4, *c5, *c6, *c7, *tempnode;
	
	rootNode=treeInit("C:\\");
	c1=treeInit("Windows");
	c2=treeInit("programs");
	c3=treeInit("addins");
	c4=treeInit("addin2");
	c5=treeInit("DSAD");
	c6=treeInit("Visual C++");

	appendChild(rootNode,c1);
	appendChild(rootNode,c2);
	appendChild(c1,c3);
	appendChild(c1,c4);
	appendChild(c2,c5);
	appendChild(c2,c6);

	exploreDirectory(rootNode,0);
	printf("\n\n");
	exploreDirectory(c1,0);
	printf("\n\n");
	exploreDirectory(c2,0);

	treeSplit(c2);
	
	printf("\n\n");

	exploreDirectory(rootNode,0);
	printf("\n\n");
	exploreDirectory(c2,0);
	
	/*
	rootNode = treeInit(str);
	
	

	c1 = treeInit(str);
	c2 = treeInit(str);
	appendChild( rootNode, c1 );
	appendChild( rootNode, c2 );

	c3 = treeInit(str);
	c4 = treeInit(str);
	appendChild( c2, c3 );
	appendChild( c2, c4 );

	c5 = treeInit(str);
	c6 = treeInit(str);
	appendChild( c3, c5 );
	appendChild( c3, c6 );

	c7 = treeInit(str);
	appendChild( c5, c7 );

	printf("��ü Ʈ�� ����\n");
	treePrint(rootNode, 0);

	printf("\n\n");

	printf("21�� ��� ã��\n");
	tempnode = treeSearch(rootNode, str);
	if(tempnode == NULL) printf("ã�� ����\n");
	else printf("ã����\n");

	printf("\n\n");

	printf("21�� ��带 �������� �� Ʈ������\n");
	treePrint(tempnode, 0);

	printf("\n\n");

	printf("21�� ��带 Ʈ������ �и��� ���� ��ü Ʈ������\n");
	treeSplit(tempnode);
	treePrint(rootNode, 0);
	
	*/
	return 0;
}

