#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<malloc.h>
#include"linkedlist.h"

LIST* ListInit(void)
{
	LIST * l=(LIST*)malloc(sizeof(LIST));
	memset(l,0,sizeof(LIST));
	l->head=(LISTNODE*)malloc(sizeof(LISTNODE));
	l->tail=(LISTNODE*)malloc(sizeof(LISTNODE));
	l->head->next=l->tail;
	l->tail->prev=l->head;
	
	return l;
}
int insert(LIST * l,Phone * data)
{
	LISTNODE * n=(LISTNODE*)malloc(sizeof(LISTNODE));
	
	n->data=(Phone*)malloc(sizeof(Phone));
	//n->data->name=(char*)malloc(30);
	//n->data->phone=(char*)malloc(30);
	//strcpy(n->data->name,data->name); // strcpy��ſ� ���ſ���; strcpy��� �ᵵ �۵��ǾߵǴ°žƴѰ���?
	//strcpy(n->data->phone,data->phone);//
	strcpy(n->data->name,data->name);
	strcpy(n->data->phone,data->phone);
	n->next=l->head->next;
	n->prev=l->head;
	l->head->next=n;
	n->next->prev=n;

	l->nodecount+=1;
	return l->nodecount;
}
void LShow(LIST * l)
{
	LISTNODE * n;
	static int i;

	for(n=l->tail->prev;n!=l->head;n=n->prev)
	{
		printf(".....List(%d).....\n",i+1);
		printf("�̸� : %s\n",n->data->name);
		printf("��ȭ��ȣ : %s\n",n->data->phone);
		i++;
	}
	i=0;
}
void Search(LIST * l, char * name)
{
	LISTNODE * n=l->head->next;

	while(1)
	{
		if(!strcmp(n->data->name,name))
		{
			printf(".....Searching Data .....\n");
			printf("Name: %s\n",n->data->name);
			printf("Phone: %s\n",n->data->phone);
			return;
		}
	}

	printf("ã�� �̸��� ��ȭ��ȣ������ �����ϴ�.\n");
	return;
}

void Delete(LIST * l, char * name)
{
	LISTNODE * n=l->head->next;

	while(1)
	{
		if(!strcmp(n->data->name,name))
		{
			n->prev->next=n->next;
			n->next->prev=n->prev;
			free(n);
			l->nodecount-=1;
			fputs("���� �Ϸ�",stdout);
			getchar();
			fflush(stdin);
			return;
		}
		n=n->next;
	}

	printf("�Է��Ͻ� �̸��� ������ �������� �ʽ��ϴ�.");
	getchar();
	fflush(stdin);
	return;
}

void LoadDataFromFile(LIST * l)
{
	FILE * fp=fopen("Phone.txt","rt");
	LISTNODE * n=(LISTNODE*)malloc(sizeof(LISTNODE));
	int i;
	int num=0;

	n->data=(Phone*)malloc(sizeof(Phone));

	if(fp==NULL)
	{
		fputs("Cannot Open the File!",stdout);
		return;
	}
	
	fread(&num,sizeof(int),1,fp);
	for(i=0;i<num;i++)
	{
		fread(n->data,sizeof(Phone),1,fp);

		insert(l,n->data);
	}
	fclose(fp);
}
void StoreDataToFile(LIST * l)
{
	FILE * fp=fopen("Phone.txt","wt");
	LISTNODE * n;

	if(fp==NULL)
	{
		fputs("Cannot open the File!",stdout);
		return;
	}

	fwrite(&l->nodecount,sizeof(int),1,fp);
	for(n=l->tail->prev;n!=l->head;n=n->prev)
	{
		fwrite(n->data,sizeof(Phone),1,fp);
	}
	fclose(fp);
}