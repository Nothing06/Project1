
#include<stdio.h>  
#include<windows.h>

int main(void)
{
	WIN32_FIND_DATA wfd;
	WIN32_FIND_DATA wfd2;
	WIN32_FIND_DATA wfd3;
	void *handle;
	void *handle2;
	void *handle3;
	char startPath[255] = "C:";
	char searchPath[25] = { 0, };
	char startPath2[255];
	int i=0;

	sprintf(searchPath, "%s\\*.*", startPath);
	handle=FindFirstFile(searchPath, &wfd);

	do{/*
		if(i==0)
		{
			printf("%s\\%s\n",startPath, wfd.cFileName);
			FindNextFile(handle,&wfd);
			printf("%s\\%s\n",startPath, wfd.cFileName);
			FindNextFile(handle,&wfd);
		}*/

		sprintf(searchPath, "%s\\%s\\*.*", startPath, wfd.cFileName);
		handle2=FindFirstFile(searchPath, &wfd2);
		do{
			FindNextFile(handle2,&wfd2);
			FindNextFile(handle2,&wfd2);

			sprintf(searchPath,"%s\\%s\\%s\\*.*",startPath, wfd.cFileName, wfd2.cFileName);
			handle3=FindFirstFile(searchPath,&wfd3);


				do{
					printf("%s\\%s\\%s\\%s\n",startPath,wfd.cFileName,wfd2.cFileName,wfd3.cFileName);
				}while(FindNextFile(handle3,&wfd3));
				
		}while(FindNextFile(handle2,&wfd2));

		//i++;
	}while(FindNextFile(handle,&wfd));

	FindClose( handle );
	
	
	return 0;
}
