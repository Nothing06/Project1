#include "linkedlist.h"

LISTNODE *searchNode( LIST *list, CompareFunc *func, void *param )
{
	LISTNODE *node = list->head->next;
	while( node != list->tail )
	{
		if( func(node, param) == 1 ) return node;
		node = node->next;
	}
	return NULL;
}


LIST *createLinkedList( void )
{
	LIST *list = (LIST*)malloc( sizeof(LIST) );
	memset(list, 0, sizeof(LIST));
	list->head = (LISTNODE*)malloc( sizeof(LISTNODE) );
	list->tail = (LISTNODE*)malloc( sizeof(LISTNODE) );
	list->head->next = list->tail;
	list->head->prev = NULL;
	list->tail->next = NULL;
	list->tail->prev = list->head;
	return list;
}

LISTNODE *createLinkedListNode( void *data )
{
	LISTNODE *node = (LISTNODE*)malloc( sizeof(LISTNODE) );
	memset(node, 0, sizeof(LISTNODE));
	node->data = data;
	return node;
}

void insertNode( LIST *list, LISTNODE *node )
{
	node->next = list->head->next;
	node->prev = list->head;
	node->next->prev = node->prev->next = node;
	list->nodeCount += 1;
}

void removeNode( LIST *list, LISTNODE *node )
{
	node->next->prev = node->prev;
	node->prev->next = node->next;
	list->nodeCount -= 1;
}
