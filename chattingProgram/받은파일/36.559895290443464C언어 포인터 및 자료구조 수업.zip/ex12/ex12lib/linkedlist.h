#ifndef _LINKED_LIST_
#define _LINKED_LIST_

#include <stdio.h>
#include <string.h>
#include <malloc.h>

typedef struct _NODE
{
	void *data;
	struct _NODE *next, *prev;
} LISTNODE;

typedef struct _LIST
{
	LISTNODE *head;
	LISTNODE *tail;
	int nodeCount;
} LIST;

typedef int CompareFunc( LISTNODE*, void* );

LIST *createLinkedList( void );
LISTNODE *createLinkedListNode( void *data );
void insertNode( LIST *list, LISTNODE *node );
void removeNode( LIST *list, LISTNODE *node );

LISTNODE *searchNode( LIST *list, CompareFunc *func, void *param );

#endif
