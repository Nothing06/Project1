#include <stdio.h>
#include "ex12lib\linkedlist.h"

#pragma comment(lib, "ex12lib\\debug\\ex12lib.lib")

typedef struct _PHONEINFO
{
	char name[512];
	char phonenumber[30];
} PHONEINFO;

int PhoneSearch( LISTNODE *node, void *param );
int NameSearch( LISTNODE *node, void *param );

int main( void )
{
	LIST *myList;
	LISTNODE *myNode;
	PHONEINFO *pi;
	int userinput;
	char buf[512] = { 0, };

	myList = createLinkedList();
	while( 1 )
	{
		printf( "1. ��ȭ��ȣ �Է�\n" );
		printf( "2. ��ȭ��ȣ �˻�\n" );
		printf( "3. ��� �̸� �˻�\n" );
		printf( "4. ������\n" );
		printf( "? " );
		scanf("%d",&userinput);

		if(userinput == 1)
		{
			pi = (PHONEINFO*)malloc( sizeof(PHONEINFO) );
			memset(pi, 0, sizeof(PHONEINFO) );
			printf("�̸�: ");
			scanf("%s",pi->name);
			printf("��ȭ��ȣ: ");
			scanf("%s",pi->phonenumber);
			myNode = createLinkedListNode(pi);
			insertNode(myList, myNode);
		}
		if(userinput == 2)
		{
			printf("��ȭ��ȣ: ");
			scanf("%s", buf);
			myNode = searchNode( myList, PhoneSearch, buf );
			if(myNode == NULL)
				printf("�߰����� ���߽��ϴ�.");
			else
			{
				pi = (PHONEINFO*)myNode->data;
				printf("�߰ߵ� ��� �̸� %s\n", pi->name);
			}
		}
		if(userinput == 3)
		{
			printf("�̸�: ");
			scanf("%s", buf);
			myNode = searchNode( myList, NameSearch, buf );
			if(myNode == NULL)
				printf("�߰����� ���߽��ϴ�.");
			else
			{
				pi = (PHONEINFO*)myNode->data;
				printf("�߰ߵ� ��ȭ��ȣ %s\n", pi->phonenumber);
			}
		}
		if(userinput == 4)
		{
			break;
		}
	}

	return 0;
}


int PhoneSearch( LISTNODE *node, void *param )
{
	char *PhoneNumber = (char*)param;
	PHONEINFO *pi = (PHONEINFO*)node->data;

	if(strcmp(pi->phonenumber, PhoneNumber)==0) return 1;
	else return 0;
}


int NameSearch( LISTNODE *node, void *param )
{
	char *name = (char*)param;
	PHONEINFO *pi = (PHONEINFO*)node->data;

	if(strcmp(pi->name, name)==0) return 1;
	else return 0;
}
