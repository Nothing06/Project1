/*
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main ( void )
{
	FILE * fp=fopen("input.txt","rt");
	char str[30]={0,};
	int num=0;
	int money=0;
	int c[]={10000,5000,1000,500,100,50,10,5,1};
	int n[9]={0,};
	int sumofn[9]={0,};
	int i;
	int sum=0;
	if(fp==NULL)
	{
		fputs("Fail!",stdout);
		exit(-1);
	}
	
	fgets(str,30,fp);
	num=atoi(str);
	
	while(fgets(str,30,fp))
	{
		money=atoi(str);
		
		for(i=0;i<9;i++)
		{
			n[i]=money/c[i];
			money=money-(n[i]*c[i]);
		}

		for(i=0;i<9;i++)
		{
			fprintf(stdout,"%d	%d\n",c[i],n[i]);
			sumofn[i]+=n[i];
		}

	}
	fclose(fp);

	fp=fopen("Output.txt","wt");
	for(i=0;i<9;i++)
	{
		fprintf(fp,"%d	%d\n",c[i],sumofn[i]);
	}
	fclose(fp);
	return 0;

}*/