#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"linkedList.h"

void ListInit(List * plist)
{
	
	plist->head=NULL;
	plist->tail=NULL;
	plist->numOfList=0;
	plist->tail=NULL;
}
void LInsert(List * plist, Data data)
{
	Node * newnode;

	newnode=(Node*)malloc(sizeof(Node));

	newnode->data=data;
	newnode->next=NULL;

	if(plist->tail==NULL)
	{
		plist->head=newnode;
		plist->tail=newnode;
		return;
	}
	
		plist->tail->next=newnode;
		plist->tail=newnode;
		
	plist->numOfList++;
	return;
}
int  LFirst(List * plist, Data * pdata)
{
	if(plist->head==NULL)
		return 0;
	
	plist->cur=plist->tail;
	*pdata=plist->cur->data;
	

	return 1;
}
int  LNext(List * plist, Data * pdata)
{
	if(plist->cur==NULL)
		return 0;
	
	*pdata=plist->cur->data;
	plist->cur=plist->cur->next;
	
	return 1;
}
Data LRemove(List * plist);
int LCount(List * plist);
