#include<stdio.h>
#include<stdlib.h>
#include"linkedList.h"

int main(void)
{
	List list;
	
	int i;
	int data=0;

	ListInit(&list);

	for(i=1;i<=10;i++)
	{
		LInsert(&list,i);
	}

	if(LFirst(&list,&data))
	{
		printf("%d ",data);
		
		while(LNext(&list, &data));
		{
			printf("%d ",data);
		}
	}

}