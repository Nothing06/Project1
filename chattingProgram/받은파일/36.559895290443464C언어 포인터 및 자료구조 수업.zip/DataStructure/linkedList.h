#ifndef __linkedList_H__
#define __linkedList_H__

typedef int Data;

typedef struct __node
{
	Data data;
	struct __node * next;
}Node;

typedef struct __linkedlist
{
	Node * head;
	Node * before;
	Node * tail;
	Node * cur;
	int numOfList;
}List;

void ListInit(List * plist);
void LInsert(List * plist, Data data);
int  LFirst(List * plist, Data * pdata);
int  LNext(List * plist, Data * pdata);
Data LRemove(List * plist);
int LCount(List * plist);

#endif
