#include <stdio.h>
#include <string.h>
#include <malloc.h>

int main( void )
{
	char *c1 = "Hello world!\n";
	char *c2 = (char*)malloc( 14 );
	strcpy( c2, c1 );

	c2[0] = 'T';
	printf( "%s\n", c2 );
	printf( "%s\n", c1 );

	return 0;
}
