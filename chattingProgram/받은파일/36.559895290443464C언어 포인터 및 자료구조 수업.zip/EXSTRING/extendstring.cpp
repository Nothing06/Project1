
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define Extralen 10
#define strLen 10
#define strArylen 5

int ExtendMemForString(char * str, int len)
{
	int i;
	char * newstr;
	newstr=(char*)malloc(len+Extralen);

	for(i=0;i<len;i++)
	{
		newstr[i]=(str)[i];
	}

	free(*str);
	*str=newstr;

	return Extralen+len;
}
char * ReadString(char * s)
{
	int i=0;
	char ch=0;
	int maxbyte=10;

	
	while(1)
	{
		if(i>=maxbyte)
			maxbyte=ExtendMemForString(s,maxbyte);
	
		ch=getchar();
		if(ch=='\n')
			break;

		s[i]=ch;
		i++;
	}
	s[i]='\0';

	return s;
}
int ACDsort(char * str1,char * str2)
{
	if(strlen(str1)>strlen(str2))
		return 1;
	else
		return 0;
}
void BubbleSort(char ** str,int (*compare)(char* , char*))
{
	int i,j;
	char * temp=NULL;
	for(i=0;i<strArylen-1;i++)
	{
		for(j=0;j<strArylen-i-1;j++)
		{
			if(compare(str[j],str[j+1]))
			{
				temp=str[j];
				str[j]=str[j+1];
				str[j+1]=temp;
			}
		}
	}

}
int main(void)
{
	char * strAry[5];
	int i;

	for(i=0;i<5;i++)
	{
		strAry[i]=(char*)malloc(strLen);
		fputs("���ڿ��Է�: ",stdout);
		strAry[i]=ReadString(strAry[i]);
	}

	BubbleSort(strAry,ACDsort);

	for(i=0;i<strArylen;i++)
	{
		puts(strAry[i]);
	}

	for(i=0;i<strArylen;i++)
	{
		free(strAry[i]);
	}

	return 0;
}
