/*
#include<stdio.h>
enum{MON=1,TUE,WED,THU,FRI,SAT,SUN,QUIT};
int main(void)
{
	int c=0;

	printf("1. ������\n");
	printf("2. ȭ����\n");
	printf("3. ������\n");
	printf("4. �����\n");
	printf("5. �ݿ���\n");
	printf("6. �����\n");
	printf("7. �Ͽ���\n");
	printf("8. ��  ��\n");

	while(1)
	{	
		printf("����>> ");
		scanf("%d",&c);

		switch(c)
		{
			case MON:
				printf("enjoy!\n");
				break;
			case TUE:
				printf("Oops!\n");
				break;
			case WED:
				printf("enjoy!\n");
				break;
			case THU:
				printf("Oops!\n");
				break;
			case FRI:
				printf("enjoy!\n");
				break;
			case SAT:
				printf("Oops!\n");
				break;
			case SUN:
				printf("Oops!\n");
				break;
			case QUIT:
				printf("�� ��\n");
				break;
			default:
				printf("WRONG number\nPlease write one of the following Numbers\n");
				break;
		}

		if(c==8)
			break;	
	}
	return 0;
}*/