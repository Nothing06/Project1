/*
#include<stdio.h>

int main(void)
{
	int arr[20]={0,};
	int i;
	int max=0;
	int max2=0;
	scanf("%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",&arr[0],&arr[1],&arr[2],&arr[3],&arr[4],&arr[5],&arr[6],&arr[7],&arr[8],&arr[9],&arr[10],&arr[11],&arr[12],&arr[13],&arr[14],&arr[15],&arr[16],&arr[17],&arr[18],&arr[19]);
	max=arr[0];
	for(i=0;i<20;i++)
	{
		if(max<arr[i])
			max=arr[i];
	}
	max2=arr[0];
	for(i=0;i<20;i++)
	{
		if(max2<max && max2<arr[i])
			max2=arr[i];
	}

	printf("%d\n",max+max2);
	printf("%d %d",max,max2);

	return 0;
}*/