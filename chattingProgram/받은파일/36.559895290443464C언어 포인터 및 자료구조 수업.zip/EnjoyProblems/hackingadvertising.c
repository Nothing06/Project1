/*
#include<stdio.h>

int main(void)
{
	int r=0;
	int e=0;
	int c=0;

	scanf("%d %d %d",&r,&e,&c);
	fflush(stdin);

	if(r>(-c+e))
		printf("do not advertise");
	else if(r<(-c+e))
		printf("advertise");
	else
		printf("does not matter");

	return 0;
}*/