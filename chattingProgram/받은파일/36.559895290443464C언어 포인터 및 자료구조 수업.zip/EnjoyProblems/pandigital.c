/*
#include<stdio.h>
#include<string.h>
int main(void)
{	
	int num=0;
	char buf[11]={0,};
	int numLen=0;
	int i;

	scanf("%d",&num);
	sprintf(buf,"%d",num);
	
	numLen=strlen(buf);

	for(i=0;i<numLen;i++)
	{
		if(i==0)
		{
			if(buf[i]>=1 && buf[i]<=numLen)
				continue;
			else
				break;
		}
		if(i==1)
		{
			if(buf[i]>=1 && buf[i]<=numLen && buf[i]!=buf[i=1])
				continue;
			else
				break;
		}
		if(i==2)
		{
			if(buf[i]>=1 && buf[i]<=numLen && buf[i]!=buf[i-1]

	}
	
	return 0;
}*/