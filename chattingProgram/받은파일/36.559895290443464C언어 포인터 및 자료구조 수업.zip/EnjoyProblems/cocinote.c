/*
#include<stdio.h>

int main( void )
{
	int str[8]={0,};
	int i;
	int cnt=0;

	for(i=0;i<8;i++)
	{
		cnt=0;
		while(str[i]<=0 || str[i]>8)
		{
			if(cnt>=1)
			{
				printf("�ٽ� �Է��� �ֽʽÿ�.\n",cnt);
			}
				printf("%d�� ���� �Է�(1~8�� �Է�): ",i+1);
				scanf("%d",&str[i]);
				cnt++;
		}
	}

	if(str[0]<=str[1] && str[1]<=str[2] && str[2]<=str[3] && str[3]<=str[4] && str[4]<=str[5] && str[5]<=str[6] && str[6]<=str[7]) 
		printf("Ascending\n");
	else if(str[0]>=str[1] && str[1]>=str[2] && str[2]>=str[3] && str[3]>=str[4] && str[4]>=str[5] && str[5]>=str[6] && str[6]>=str[7])
		printf("Descending\n");
	else 
		printf("mixed\n");
	
	return 0;
}*/