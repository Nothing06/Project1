#include<stdio.h>

int main( void )
{
	int arr[7];
	int i;
	int sum=0;
	int min=0;

	for(i=0;i<7;i++)
	{
		while(arr[i]<=0 || arr[i]>100)
		{
			scanf("%d",&arr[i]);
		}
	}
	min=100;
	for(i=0;i<7;i++)
	{
		if(arr[i]%2)
			sum+=arr[i];
		if(min>arr[i] && arr[i]%2==1)
		{
			min=arr[i];
		}
	}

	if(sum==0)
	{
		printf("-1");
	}
	else
	{
		printf("%d\n",sum);
		printf("%d",min);
	}

	return 0;
}