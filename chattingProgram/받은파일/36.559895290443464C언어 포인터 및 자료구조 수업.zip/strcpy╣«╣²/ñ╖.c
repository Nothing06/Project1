#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main (void)
{
	char *str1=(char*)malloc(30);
	char *str2=(char*)malloc(30);

	fputs("str2�Է�: ",stdout);
	gets(str2);

	str1=str2;

	puts(str1);
}