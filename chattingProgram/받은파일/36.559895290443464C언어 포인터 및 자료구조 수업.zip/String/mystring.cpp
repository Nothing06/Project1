#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <conio.h> // getch()

char *getLongString( void )
{
	char c=0;
	char * str=NULL;

	do
	{
		c=getchar();
		
		if(c=='\n')
		{
			break;
		}
		
		if(str==NULL)
		{
			str=(char*)malloc(sizeof(char)*2);
			memset(str,0,2);
		}
		else
		{
			char * temp=(char*)malloc(strlen(str)+1+1);
			memset(temp,0,strlen(str)+1+1);
			strcpy(temp,str);

			str=(char*)malloc(strlen(temp)+1+1);
			memset(str,0,strlen(temp)+1+1);
			strcpy(str,temp);
			free(temp);
		}
		
		str[strlen(str)]=c;
	}while(1);

	return str;
}

int main(void)
{
	printf("����: ");
	char * str1=getLongString();
	printf("����: ");
	char * str2=getLongString();
	printf("����: ");
	char * str3=getLongString();
	printf("����: ");
	char * str4=getLongString();
	printf("����: ");
	char * str5=getLongString();

	int maxlength=0;
	int index=0;
	int loop=0;

	for(loop=0;loop<5;loop+=1)
	{
		maxlength=0;
	if(strlen(str1)!=0 && strlen(str1)>maxlength) { index=0; maxlength=strlen(str1);}
	if(strlen(str2)!=0 && strlen(str2)>maxlength) { index=1; maxlength=strlen(str2);}
	if(strlen(str3)!=0 && strlen(str3)>maxlength) { index=2; maxlength=strlen(str3);}
	if(strlen(str4)!=0 && strlen(str4)>maxlength) { index=3; maxlength=strlen(str4);}
	if(strlen(str5)!=0 && strlen(str5)>maxlength) { index=4; maxlength=strlen(str5);}
	if(index==0) { printf("%s\n",str1); str1[0]=0; }
	if(index==1) { printf("%s\n",str2); str2[0]=0; }
	if(index==2) { printf("%s\n",str3); str3[0]=0;}
	if(index==3) { printf("%s\n",str4); str4[0]=0;}
	if(index==4) { printf("%s\n",str5); str5[0]=0;}
	}
	return 0;
}
